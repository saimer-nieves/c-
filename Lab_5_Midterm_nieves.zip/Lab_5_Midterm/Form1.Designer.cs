﻿namespace Lab_5_Midterm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblfirst_name = new System.Windows.Forms.Label();
            this.lblmiddle_name = new System.Windows.Forms.Label();
            this.lbllast_name = new System.Windows.Forms.Label();
            this.lblstreet_1 = new System.Windows.Forms.Label();
            this.lblstreet_2 = new System.Windows.Forms.Label();
            this.lblcity = new System.Windows.Forms.Label();
            this.lblstate = new System.Windows.Forms.Label();
            this.lblzip_code = new System.Windows.Forms.Label();
            this.lblphone = new System.Windows.Forms.Label();
            this.lblemail = new System.Windows.Forms.Label();
            this.txtfirst_name = new System.Windows.Forms.TextBox();
            this.txtmiddle_name = new System.Windows.Forms.TextBox();
            this.txtlast_name = new System.Windows.Forms.TextBox();
            this.txtstreet_1 = new System.Windows.Forms.TextBox();
            this.txtstreet_2 = new System.Windows.Forms.TextBox();
            this.txtcity = new System.Windows.Forms.TextBox();
            this.txtstate = new System.Windows.Forms.TextBox();
            this.txtzip_code = new System.Windows.Forms.TextBox();
            this.txtphone = new System.Windows.Forms.TextBox();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.btnAdd_person = new System.Windows.Forms.Button();
            this.lblFeedBack = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblfirst_name
            // 
            this.lblfirst_name.AutoSize = true;
            this.lblfirst_name.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfirst_name.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblfirst_name.Location = new System.Drawing.Point(34, 60);
            this.lblfirst_name.Name = "lblfirst_name";
            this.lblfirst_name.Size = new System.Drawing.Size(77, 18);
            this.lblfirst_name.TabIndex = 0;
            this.lblfirst_name.Text = "First Name: ";
            this.lblfirst_name.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblmiddle_name
            // 
            this.lblmiddle_name.AutoSize = true;
            this.lblmiddle_name.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmiddle_name.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblmiddle_name.Location = new System.Drawing.Point(21, 95);
            this.lblmiddle_name.Name = "lblmiddle_name";
            this.lblmiddle_name.Size = new System.Drawing.Size(90, 18);
            this.lblmiddle_name.TabIndex = 1;
            this.lblmiddle_name.Text = "Middle Name: ";
            // 
            // lbllast_name
            // 
            this.lbllast_name.AutoSize = true;
            this.lbllast_name.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbllast_name.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbllast_name.Location = new System.Drawing.Point(35, 127);
            this.lbllast_name.Name = "lbllast_name";
            this.lbllast_name.Size = new System.Drawing.Size(76, 18);
            this.lbllast_name.TabIndex = 2;
            this.lbllast_name.Text = "Last Name: ";
            // 
            // lblstreet_1
            // 
            this.lblstreet_1.AutoSize = true;
            this.lblstreet_1.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstreet_1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblstreet_1.Location = new System.Drawing.Point(311, 60);
            this.lblstreet_1.Name = "lblstreet_1";
            this.lblstreet_1.Size = new System.Drawing.Size(118, 18);
            this.lblstreet_1.TabIndex = 3;
            this.lblstreet_1.Text = "1st Street Address: ";
            // 
            // lblstreet_2
            // 
            this.lblstreet_2.AutoSize = true;
            this.lblstreet_2.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstreet_2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblstreet_2.Location = new System.Drawing.Point(311, 95);
            this.lblstreet_2.Name = "lblstreet_2";
            this.lblstreet_2.Size = new System.Drawing.Size(115, 18);
            this.lblstreet_2.TabIndex = 4;
            this.lblstreet_2.Text = "2nd Street Address";
            // 
            // lblcity
            // 
            this.lblcity.AutoSize = true;
            this.lblcity.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcity.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblcity.Location = new System.Drawing.Point(311, 135);
            this.lblcity.Name = "lblcity";
            this.lblcity.Size = new System.Drawing.Size(39, 18);
            this.lblcity.TabIndex = 5;
            this.lblcity.Text = "City: ";
            // 
            // lblstate
            // 
            this.lblstate.AutoSize = true;
            this.lblstate.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstate.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblstate.Location = new System.Drawing.Point(529, 137);
            this.lblstate.Name = "lblstate";
            this.lblstate.Size = new System.Drawing.Size(89, 18);
            this.lblstate.TabIndex = 6;
            this.lblstate.Text = "State Initials: ";
            // 
            // lblzip_code
            // 
            this.lblzip_code.AutoSize = true;
            this.lblzip_code.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblzip_code.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblzip_code.Location = new System.Drawing.Point(562, 176);
            this.lblzip_code.Name = "lblzip_code";
            this.lblzip_code.Size = new System.Drawing.Size(66, 18);
            this.lblzip_code.TabIndex = 7;
            this.lblzip_code.Text = "Zip Code: ";
            // 
            // lblphone
            // 
            this.lblphone.AutoSize = true;
            this.lblphone.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblphone.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblphone.Location = new System.Drawing.Point(148, 224);
            this.lblphone.Name = "lblphone";
            this.lblphone.Size = new System.Drawing.Size(98, 18);
            this.lblphone.TabIndex = 8;
            this.lblphone.Text = "Phone Number: ";
            // 
            // lblemail
            // 
            this.lblemail.AutoSize = true;
            this.lblemail.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblemail.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblemail.Location = new System.Drawing.Point(453, 224);
            this.lblemail.Name = "lblemail";
            this.lblemail.Size = new System.Drawing.Size(96, 18);
            this.lblemail.TabIndex = 9;
            this.lblemail.Text = "Email Address: ";
            // 
            // txtfirst_name
            // 
            this.txtfirst_name.Location = new System.Drawing.Point(144, 60);
            this.txtfirst_name.Name = "txtfirst_name";
            this.txtfirst_name.Size = new System.Drawing.Size(130, 22);
            this.txtfirst_name.TabIndex = 10;
            // 
            // txtmiddle_name
            // 
            this.txtmiddle_name.Location = new System.Drawing.Point(144, 91);
            this.txtmiddle_name.Name = "txtmiddle_name";
            this.txtmiddle_name.Size = new System.Drawing.Size(130, 22);
            this.txtmiddle_name.TabIndex = 11;
            // 
            // txtlast_name
            // 
            this.txtlast_name.Location = new System.Drawing.Point(143, 127);
            this.txtlast_name.Name = "txtlast_name";
            this.txtlast_name.Size = new System.Drawing.Size(130, 22);
            this.txtlast_name.TabIndex = 12;
            // 
            // txtstreet_1
            // 
            this.txtstreet_1.Location = new System.Drawing.Point(495, 56);
            this.txtstreet_1.Name = "txtstreet_1";
            this.txtstreet_1.Size = new System.Drawing.Size(293, 22);
            this.txtstreet_1.TabIndex = 13;
            // 
            // txtstreet_2
            // 
            this.txtstreet_2.Location = new System.Drawing.Point(495, 93);
            this.txtstreet_2.Name = "txtstreet_2";
            this.txtstreet_2.Size = new System.Drawing.Size(293, 22);
            this.txtstreet_2.TabIndex = 14;
            // 
            // txtcity
            // 
            this.txtcity.Location = new System.Drawing.Point(360, 133);
            this.txtcity.Name = "txtcity";
            this.txtcity.Size = new System.Drawing.Size(130, 22);
            this.txtcity.TabIndex = 15;
            // 
            // txtstate
            // 
            this.txtstate.Location = new System.Drawing.Point(646, 133);
            this.txtstate.Name = "txtstate";
            this.txtstate.Size = new System.Drawing.Size(130, 22);
            this.txtstate.TabIndex = 16;
            // 
            // txtzip_code
            // 
            this.txtzip_code.Location = new System.Drawing.Point(646, 174);
            this.txtzip_code.Name = "txtzip_code";
            this.txtzip_code.Size = new System.Drawing.Size(130, 22);
            this.txtzip_code.TabIndex = 17;
            // 
            // txtphone
            // 
            this.txtphone.Location = new System.Drawing.Point(127, 245);
            this.txtphone.Name = "txtphone";
            this.txtphone.Size = new System.Drawing.Size(169, 22);
            this.txtphone.TabIndex = 18;
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(385, 245);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(268, 22);
            this.txtemail.TabIndex = 19;
            this.txtemail.TextChanged += new System.EventHandler(this.textBox10_TextChanged);
            // 
            // btnAdd_person
            // 
            this.btnAdd_person.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd_person.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.btnAdd_person.Location = new System.Drawing.Point(293, 312);
            this.btnAdd_person.Name = "btnAdd_person";
            this.btnAdd_person.Size = new System.Drawing.Size(150, 54);
            this.btnAdd_person.TabIndex = 20;
            this.btnAdd_person.Text = "Add Person";
            this.btnAdd_person.UseVisualStyleBackColor = true;
            this.btnAdd_person.Click += new System.EventHandler(this.btnAdd_person_Click);
            // 
            // lblFeedBack
            // 
            this.lblFeedBack.AutoSize = true;
            this.lblFeedBack.ForeColor = System.Drawing.Color.Red;
            this.lblFeedBack.Location = new System.Drawing.Point(124, 392);
            this.lblFeedBack.Name = "lblFeedBack";
            this.lblFeedBack.Size = new System.Drawing.Size(122, 16);
            this.lblFeedBack.TabIndex = 21;
            this.lblFeedBack.Text = "Feed Back Section";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(223, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(280, 16);
            this.label2.TabIndex = 23;
            this.label2.Text = "Form To Add People By Saimer Nieves";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblFeedBack);
            this.Controls.Add(this.btnAdd_person);
            this.Controls.Add(this.txtemail);
            this.Controls.Add(this.txtphone);
            this.Controls.Add(this.txtzip_code);
            this.Controls.Add(this.txtstate);
            this.Controls.Add(this.txtcity);
            this.Controls.Add(this.txtstreet_2);
            this.Controls.Add(this.txtstreet_1);
            this.Controls.Add(this.txtlast_name);
            this.Controls.Add(this.txtmiddle_name);
            this.Controls.Add(this.txtfirst_name);
            this.Controls.Add(this.lblemail);
            this.Controls.Add(this.lblphone);
            this.Controls.Add(this.lblzip_code);
            this.Controls.Add(this.lblstate);
            this.Controls.Add(this.lblcity);
            this.Controls.Add(this.lblstreet_2);
            this.Controls.Add(this.lblstreet_1);
            this.Controls.Add(this.lbllast_name);
            this.Controls.Add(this.lblmiddle_name);
            this.Controls.Add(this.lblfirst_name);
            this.ForeColor = System.Drawing.Color.CadetBlue;
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblfirst_name;
        private System.Windows.Forms.Label lblmiddle_name;
        private System.Windows.Forms.Label lbllast_name;
        private System.Windows.Forms.Label lblstreet_1;
        private System.Windows.Forms.Label lblstreet_2;
        private System.Windows.Forms.Label lblcity;
        private System.Windows.Forms.Label lblstate;
        private System.Windows.Forms.Label lblzip_code;
        private System.Windows.Forms.Label lblphone;
        private System.Windows.Forms.Label lblemail;
        private System.Windows.Forms.TextBox txtfirst_name;
        private System.Windows.Forms.TextBox txtmiddle_name;
        private System.Windows.Forms.TextBox txtlast_name;
        private System.Windows.Forms.TextBox txtstreet_1;
        private System.Windows.Forms.TextBox txtstreet_2;
        private System.Windows.Forms.TextBox txtcity;
        private System.Windows.Forms.TextBox txtstate;
        private System.Windows.Forms.TextBox txtzip_code;
        private System.Windows.Forms.TextBox txtphone;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.Button btnAdd_person;
        private System.Windows.Forms.Label lblFeedBack;
        private System.Windows.Forms.Label label2;
    }
}

