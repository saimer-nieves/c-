﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_4
{
    class ValidationLibrary //begins the validation Library
    {
        //Protects code from including the poop name
        public static bool poop_blocker(string temp)
        {
            //sets bool =  to true and if poop is found changes the value to false
            bool result = false;
            if (temp.Contains("poop"))
            {
                result = true;
            }
            return result;


        }
        //Checks to make sure atleast something was left added in
        public static bool IsFilledIn(string temp)
        {
            //sets bool value = to false and if value is greater then 1 it becomes true
            bool result = false;
            if (temp.Length > 0)
            {
                result = true;
            }

            return result;
        }

        //Checks there is a minimum length the same as fill but modified
        public static bool IsFilledmin(string temp, int minlen)
        {
            //Uses the same formula with a minimum however to secure minimum length is secure
            bool result = false;
            if (temp.Length >= minlen)
            {
                result = true;
            }
            return result;
        }

        public static bool IsFilledIn_max(string temp, int max_length)
        {
            //secures user types in maximum length such as for phone numbers and zip codes in the usa
            bool result = false;
            if (temp.Length == max_length)
            {
                result = true;
            }
            return result;
        }

        public static bool Phone_checker(string temp) // A phone checker to secure typed in phone includes dashes seperating its values
        {
            bool blnResult = true;
            //Searches for -
            int Phone_divider = temp.IndexOf("-");
            int Next_Phone_Divider = temp.IndexOf("-", Phone_divider + 1); // searches for values index then adds 1 to it if its less the 2 it remains true 

            //Loks for position of last period

            if (Next_Phone_Divider >= 2)
            {
                blnResult = false;
            }


            return blnResult;

        }


        public static bool ValidEmail(string temp) // searches for the @ symbol to secure correct email format is typed in
        {
            bool blnResult = true;
            //Searches for @
            int atLocation = temp.IndexOf("@");
            int NextatLocation = temp.IndexOf("@", atLocation + 1);

            //Loks for position of last period
            int periodLocation = temp.LastIndexOf(".");

            if (temp.Length < 8)
            {
                blnResult = false;
            }
            else if (atLocation < 2)
            {
                blnResult = false;
            }
            else if (periodLocation + 2 > (temp.Length))
            {
                blnResult = false;
            }

            return blnResult;

        }
    }
}
