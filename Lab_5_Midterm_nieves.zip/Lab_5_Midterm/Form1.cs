﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_5_Midterm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAdd_person_Click(object sender, EventArgs e) // this is the property that takes action once you click on something
        {
            //This is the label name
            

            Person temp = new Person();
   
            temp.Email_address = txtemail.Text;
            temp.Phone_number = txtphone.Text;
            temp.Zip_code = txtzip_code.Text;
            temp.State = txtstate.Text;
            temp.City = txtcity.Text;
            temp.Street_2 = txtstreet_2.Text;
            temp.Street_1 = txtstreet_1.Text;
            temp.Last_name = txtlast_name.Text;
            temp.Middle_name = txtmiddle_name.Text;
            temp.First_name = txtfirst_name.Text;


            if (temp.Feedback.Contains("INVALID: "))
            {
                lblFeedBack.Text = temp.Feedback;

            }
            else
            {
                lblFeedBack.Text = "Person Added:  " + temp.First_name + " - " + temp.Middle_name + " - " + temp.Last_name + "\nFirst Name:  "+ temp.First_name + "\nMiddle Name:  " + temp.Middle_name + "\nLast Name:  " + temp.Last_name + " \nAddress 1:  " + temp.Street_1 + " \nAddress 2:  " + temp.Street_2 + "\nCity:  " + temp.City + " \nState:  " + temp.State + "\nZip Code:  " + temp.Zip_code + "\nPhone Number:  " + temp.Phone_number + "\nEmail Address:  " + temp.Email_address;
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
