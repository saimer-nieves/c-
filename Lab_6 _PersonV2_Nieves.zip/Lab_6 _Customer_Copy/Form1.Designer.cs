﻿namespace Lab_5_Midterm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblfirst_name = new System.Windows.Forms.Label();
            this.lblmiddle_name = new System.Windows.Forms.Label();
            this.lbllast_name = new System.Windows.Forms.Label();
            this.lblstreet_1 = new System.Windows.Forms.Label();
            this.lblstreet_2 = new System.Windows.Forms.Label();
            this.lblcity = new System.Windows.Forms.Label();
            this.lblstate = new System.Windows.Forms.Label();
            this.lblzip_code = new System.Windows.Forms.Label();
            this.lblphone = new System.Windows.Forms.Label();
            this.lblemail = new System.Windows.Forms.Label();
            this.txtfirst_name = new System.Windows.Forms.TextBox();
            this.txtmiddle_name = new System.Windows.Forms.TextBox();
            this.txtlast_name = new System.Windows.Forms.TextBox();
            this.txtstreet_1 = new System.Windows.Forms.TextBox();
            this.txtstreet_2 = new System.Windows.Forms.TextBox();
            this.txtcity = new System.Windows.Forms.TextBox();
            this.txtstate = new System.Windows.Forms.TextBox();
            this.txtzip_code = new System.Windows.Forms.TextBox();
            this.txtphone = new System.Windows.Forms.TextBox();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.btnAdd_person = new System.Windows.Forms.Button();
            this.lblFeedBack = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCell_Phone = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtInstagramURL = new System.Windows.Forms.TextBox();
            this.lblInstagramURL = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txttotal_purchases = new System.Windows.Forms.TextBox();
            this.chkdiscount_member = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dtpcustomer_since = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.numlistRewards = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numlistRewards)).BeginInit();
            this.SuspendLayout();
            // 
            // lblfirst_name
            // 
            this.lblfirst_name.AutoSize = true;
            this.lblfirst_name.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfirst_name.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblfirst_name.Location = new System.Drawing.Point(24, 46);
            this.lblfirst_name.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblfirst_name.Name = "lblfirst_name";
            this.lblfirst_name.Size = new System.Drawing.Size(77, 18);
            this.lblfirst_name.TabIndex = 0;
            this.lblfirst_name.Text = "First Name: ";
            this.lblfirst_name.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblmiddle_name
            // 
            this.lblmiddle_name.AutoSize = true;
            this.lblmiddle_name.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmiddle_name.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblmiddle_name.Location = new System.Drawing.Point(15, 71);
            this.lblmiddle_name.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblmiddle_name.Name = "lblmiddle_name";
            this.lblmiddle_name.Size = new System.Drawing.Size(90, 18);
            this.lblmiddle_name.TabIndex = 1;
            this.lblmiddle_name.Text = "Middle Name: ";
            // 
            // lbllast_name
            // 
            this.lbllast_name.AutoSize = true;
            this.lbllast_name.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbllast_name.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbllast_name.Location = new System.Drawing.Point(24, 95);
            this.lbllast_name.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbllast_name.Name = "lbllast_name";
            this.lbllast_name.Size = new System.Drawing.Size(76, 18);
            this.lbllast_name.TabIndex = 2;
            this.lbllast_name.Text = "Last Name: ";
            // 
            // lblstreet_1
            // 
            this.lblstreet_1.AutoSize = true;
            this.lblstreet_1.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstreet_1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblstreet_1.Location = new System.Drawing.Point(218, 46);
            this.lblstreet_1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblstreet_1.Name = "lblstreet_1";
            this.lblstreet_1.Size = new System.Drawing.Size(118, 18);
            this.lblstreet_1.TabIndex = 3;
            this.lblstreet_1.Text = "1st Street Address: ";
            // 
            // lblstreet_2
            // 
            this.lblstreet_2.AutoSize = true;
            this.lblstreet_2.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstreet_2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblstreet_2.Location = new System.Drawing.Point(218, 71);
            this.lblstreet_2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblstreet_2.Name = "lblstreet_2";
            this.lblstreet_2.Size = new System.Drawing.Size(115, 18);
            this.lblstreet_2.TabIndex = 4;
            this.lblstreet_2.Text = "2nd Street Address";
            // 
            // lblcity
            // 
            this.lblcity.AutoSize = true;
            this.lblcity.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcity.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblcity.Location = new System.Drawing.Point(218, 102);
            this.lblcity.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblcity.Name = "lblcity";
            this.lblcity.Size = new System.Drawing.Size(39, 18);
            this.lblcity.TabIndex = 5;
            this.lblcity.Text = "City: ";
            // 
            // lblstate
            // 
            this.lblstate.AutoSize = true;
            this.lblstate.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstate.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblstate.Location = new System.Drawing.Point(370, 102);
            this.lblstate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblstate.Name = "lblstate";
            this.lblstate.Size = new System.Drawing.Size(89, 18);
            this.lblstate.TabIndex = 6;
            this.lblstate.Text = "State Initials: ";
            // 
            // lblzip_code
            // 
            this.lblzip_code.AutoSize = true;
            this.lblzip_code.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblzip_code.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblzip_code.Location = new System.Drawing.Point(394, 132);
            this.lblzip_code.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblzip_code.Name = "lblzip_code";
            this.lblzip_code.Size = new System.Drawing.Size(66, 18);
            this.lblzip_code.TabIndex = 7;
            this.lblzip_code.Text = "Zip Code: ";
            // 
            // lblphone
            // 
            this.lblphone.AutoSize = true;
            this.lblphone.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblphone.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblphone.Location = new System.Drawing.Point(54, 146);
            this.lblphone.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblphone.Name = "lblphone";
            this.lblphone.Size = new System.Drawing.Size(139, 18);
            this.lblphone.TabIndex = 8;
            this.lblphone.Text = "Phone Number(Home): ";
            // 
            // lblemail
            // 
            this.lblemail.AutoSize = true;
            this.lblemail.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblemail.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblemail.Location = new System.Drawing.Point(321, 166);
            this.lblemail.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblemail.Name = "lblemail";
            this.lblemail.Size = new System.Drawing.Size(96, 18);
            this.lblemail.TabIndex = 9;
            this.lblemail.Text = "Email Address: ";
            // 
            // txtfirst_name
            // 
            this.txtfirst_name.Location = new System.Drawing.Point(101, 46);
            this.txtfirst_name.Margin = new System.Windows.Forms.Padding(2);
            this.txtfirst_name.Name = "txtfirst_name";
            this.txtfirst_name.Size = new System.Drawing.Size(104, 21);
            this.txtfirst_name.TabIndex = 10;
            // 
            // txtmiddle_name
            // 
            this.txtmiddle_name.Location = new System.Drawing.Point(101, 68);
            this.txtmiddle_name.Margin = new System.Windows.Forms.Padding(2);
            this.txtmiddle_name.Name = "txtmiddle_name";
            this.txtmiddle_name.Size = new System.Drawing.Size(104, 21);
            this.txtmiddle_name.TabIndex = 11;
            // 
            // txtlast_name
            // 
            this.txtlast_name.Location = new System.Drawing.Point(100, 95);
            this.txtlast_name.Margin = new System.Windows.Forms.Padding(2);
            this.txtlast_name.Name = "txtlast_name";
            this.txtlast_name.Size = new System.Drawing.Size(105, 21);
            this.txtlast_name.TabIndex = 12;
            // 
            // txtstreet_1
            // 
            this.txtstreet_1.Location = new System.Drawing.Point(346, 42);
            this.txtstreet_1.Margin = new System.Windows.Forms.Padding(2);
            this.txtstreet_1.Name = "txtstreet_1";
            this.txtstreet_1.Size = new System.Drawing.Size(165, 17);
            this.txtstreet_1.TabIndex = 13;
            // 
            // txtstreet_2
            // 
            this.txtstreet_2.Location = new System.Drawing.Point(346, 70);
            this.txtstreet_2.Margin = new System.Windows.Forms.Padding(2);
            this.txtstreet_2.Name = "txtstreet_2";
            this.txtstreet_2.Size = new System.Drawing.Size(165, 17);
            this.txtstreet_2.TabIndex = 14;
            // 
            // txtcity
            // 
            this.txtcity.Location = new System.Drawing.Point(252, 100);
            this.txtcity.Margin = new System.Windows.Forms.Padding(2);
            this.txtcity.Name = "txtcity";
            this.txtcity.Size = new System.Drawing.Size(73, 17);
            this.txtcity.TabIndex = 15;
            // 
            // txtstate
            // 
            this.txtstate.Location = new System.Drawing.Point(452, 100);
            this.txtstate.Margin = new System.Windows.Forms.Padding(2);
            this.txtstate.Name = "txtstate";
            this.txtstate.Size = new System.Drawing.Size(73, 17);
            this.txtstate.TabIndex = 16;
            this.txtstate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtstate_KeyPress);
            // 
            // txtzip_code
            // 
            this.txtzip_code.Location = new System.Drawing.Point(452, 130);
            this.txtzip_code.Margin = new System.Windows.Forms.Padding(2);
            this.txtzip_code.Name = "txtzip_code";
            this.txtzip_code.Size = new System.Drawing.Size(73, 17);
            this.txtzip_code.TabIndex = 17;
            this.txtzip_code.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtzip_code_KeyPress);
            // 
            // txtphone
            // 
            this.txtphone.Location = new System.Drawing.Point(73, 184);
            this.txtphone.Margin = new System.Windows.Forms.Padding(2);
            this.txtphone.Name = "txtphone";
            this.txtphone.Size = new System.Drawing.Size(95, 17);
            this.txtphone.TabIndex = 18;
            this.txtphone.TextChanged += new System.EventHandler(this.txtphone_TextChanged);
            this.txtphone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtphone_KeyPress);
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(292, 186);
            this.txtemail.Margin = new System.Windows.Forms.Padding(2);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(150, 21);
            this.txtemail.TabIndex = 19;
            this.txtemail.TextChanged += new System.EventHandler(this.textBox10_TextChanged);
            // 
            // btnAdd_person
            // 
            this.btnAdd_person.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd_person.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.btnAdd_person.Location = new System.Drawing.Point(220, 430);
            this.btnAdd_person.Margin = new System.Windows.Forms.Padding(2);
            this.btnAdd_person.Name = "btnAdd_person";
            this.btnAdd_person.Size = new System.Drawing.Size(105, 41);
            this.btnAdd_person.TabIndex = 20;
            this.btnAdd_person.Text = "Add Person";
            this.btnAdd_person.UseVisualStyleBackColor = true;
            this.btnAdd_person.Click += new System.EventHandler(this.btnAdd_person_Click);
            // 
            // lblFeedBack
            // 
            this.lblFeedBack.AutoSize = true;
            this.lblFeedBack.ForeColor = System.Drawing.Color.Red;
            this.lblFeedBack.Location = new System.Drawing.Point(69, 470);
            this.lblFeedBack.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblFeedBack.Name = "lblFeedBack";
            this.lblFeedBack.Size = new System.Drawing.Size(98, 13);
            this.lblFeedBack.TabIndex = 21;
            this.lblFeedBack.Text = "Feed Back Section";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(156, 6);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(280, 16);
            this.label2.TabIndex = 23;
            this.label2.Text = "Form To Add People By Saimer Nieves";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // txtCell_Phone
            // 
            this.txtCell_Phone.Location = new System.Drawing.Point(73, 256);
            this.txtCell_Phone.Margin = new System.Windows.Forms.Padding(2);
            this.txtCell_Phone.Name = "txtCell_Phone";
            this.txtCell_Phone.Size = new System.Drawing.Size(95, 21);
            this.txtCell_Phone.TabIndex = 24;
            this.txtCell_Phone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCell_Phone_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(86, 221);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 18);
            this.label1.TabIndex = 25;
            this.label1.Text = "Cell Phone: ";
            // 
            // txtInstagramURL
            // 
            this.txtInstagramURL.Location = new System.Drawing.Point(286, 256);
            this.txtInstagramURL.Margin = new System.Windows.Forms.Padding(2);
            this.txtInstagramURL.Name = "txtInstagramURL";
            this.txtInstagramURL.Size = new System.Drawing.Size(150, 21);
            this.txtInstagramURL.TabIndex = 26;
            // 
            // lblInstagramURL
            // 
            this.lblInstagramURL.AutoSize = true;
            this.lblInstagramURL.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstagramURL.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblInstagramURL.Location = new System.Drawing.Point(289, 236);
            this.lblInstagramURL.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblInstagramURL.Name = "lblInstagramURL";
            this.lblInstagramURL.Size = new System.Drawing.Size(147, 18);
            this.lblInstagramURL.TabIndex = 27;
            this.lblInstagramURL.Text = "Instagram Account URL";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(315, 362);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 18);
            this.label3.TabIndex = 35;
            this.label3.Text = "Rewards Earned";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(61, 362);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(101, 18);
            this.label4.TabIndex = 33;
            this.label4.Text = "Total Purchases";
            // 
            // txttotal_purchases
            // 
            this.txttotal_purchases.Enabled = false;
            this.txttotal_purchases.Location = new System.Drawing.Point(100, 382);
            this.txttotal_purchases.Margin = new System.Windows.Forms.Padding(2);
            this.txttotal_purchases.Name = "txttotal_purchases";
            this.txttotal_purchases.Size = new System.Drawing.Size(36, 21);
            this.txttotal_purchases.TabIndex = 32;
            this.txttotal_purchases.Tag = "";
            this.txttotal_purchases.TextChanged += new System.EventHandler(this.txttotal_purchases_TextChanged);
            this.txttotal_purchases.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txttotal_purchases_KeyPress);
            // 
            // chkdiscount_member
            // 
            this.chkdiscount_member.AutoSize = true;
            this.chkdiscount_member.Enabled = false;
            this.chkdiscount_member.Location = new System.Drawing.Point(306, 330);
            this.chkdiscount_member.Name = "chkdiscount_member";
            this.chkdiscount_member.Size = new System.Drawing.Size(199, 20);
            this.chkdiscount_member.TabIndex = 37;
            this.chkdiscount_member.Text = "Yes, I am a discount member";
            this.chkdiscount_member.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Location = new System.Drawing.Point(303, 311);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 18);
            this.label5.TabIndex = 38;
            this.label5.Text = "Discount Member: ";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // dtpcustomer_since
            // 
            this.dtpcustomer_since.Enabled = false;
            this.dtpcustomer_since.Location = new System.Drawing.Point(47, 330);
            this.dtpcustomer_since.Name = "dtpcustomer_since";
            this.dtpcustomer_since.Size = new System.Drawing.Size(217, 21);
            this.dtpcustomer_since.TabIndex = 39;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Location = new System.Drawing.Point(86, 308);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 18);
            this.label6.TabIndex = 28;
            this.label6.Text = "Customer Since:";
            // 
            // numlistRewards
            // 
            this.numlistRewards.Enabled = false;
            this.numlistRewards.Location = new System.Drawing.Point(331, 382);
            this.numlistRewards.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numlistRewards.Name = "numlistRewards";
            this.numlistRewards.Size = new System.Drawing.Size(62, 21);
            this.numlistRewards.TabIndex = 40;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(114, 164);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 13);
            this.label7.TabIndex = 41;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Palatino Linotype", 7.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label8.Location = new System.Drawing.Point(44, 164);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(164, 15);
            this.label8.TabIndex = 42;
            this.label8.Text = "Include Dashes (401-999-9999)";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Palatino Linotype", 7.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label9.Location = new System.Drawing.Point(41, 239);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(164, 15);
            this.label9.TabIndex = 43;
            this.label9.Text = "Include Dashes (401-999-9999)";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label10.Location = new System.Drawing.Point(140, 380);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(90, 18);
            this.label10.TabIndex = 44;
            this.label10.Text = "Ex -> 5 or 5.56";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(729, 635);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.numlistRewards);
            this.Controls.Add(this.dtpcustomer_since);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.chkdiscount_member);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txttotal_purchases);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblInstagramURL);
            this.Controls.Add(this.txtInstagramURL);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtCell_Phone);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblFeedBack);
            this.Controls.Add(this.btnAdd_person);
            this.Controls.Add(this.txtemail);
            this.Controls.Add(this.txtphone);
            this.Controls.Add(this.txtzip_code);
            this.Controls.Add(this.txtstate);
            this.Controls.Add(this.txtcity);
            this.Controls.Add(this.txtstreet_2);
            this.Controls.Add(this.txtstreet_1);
            this.Controls.Add(this.txtlast_name);
            this.Controls.Add(this.txtmiddle_name);
            this.Controls.Add(this.txtfirst_name);
            this.Controls.Add(this.lblemail);
            this.Controls.Add(this.lblphone);
            this.Controls.Add(this.lblzip_code);
            this.Controls.Add(this.lblstate);
            this.Controls.Add(this.lblcity);
            this.Controls.Add(this.lblstreet_2);
            this.Controls.Add(this.lblstreet_1);
            this.Controls.Add(this.lbllast_name);
            this.Controls.Add(this.lblmiddle_name);
            this.Controls.Add(this.lblfirst_name);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.CadetBlue;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.numlistRewards)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblfirst_name;
        private System.Windows.Forms.Label lblmiddle_name;
        private System.Windows.Forms.Label lbllast_name;
        private System.Windows.Forms.Label lblstreet_1;
        private System.Windows.Forms.Label lblstreet_2;
        private System.Windows.Forms.Label lblcity;
        private System.Windows.Forms.Label lblstate;
        private System.Windows.Forms.Label lblzip_code;
        private System.Windows.Forms.Label lblphone;
        private System.Windows.Forms.Label lblemail;
        private System.Windows.Forms.TextBox txtfirst_name;
        private System.Windows.Forms.TextBox txtmiddle_name;
        private System.Windows.Forms.TextBox txtlast_name;
        private System.Windows.Forms.TextBox txtstreet_1;
        private System.Windows.Forms.TextBox txtstreet_2;
        private System.Windows.Forms.TextBox txtcity;
        private System.Windows.Forms.TextBox txtstate;
        private System.Windows.Forms.TextBox txtzip_code;
        private System.Windows.Forms.TextBox txtphone;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.Button btnAdd_person;
        private System.Windows.Forms.Label lblFeedBack;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCell_Phone;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtInstagramURL;
        private System.Windows.Forms.Label lblInstagramURL;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txttotal_purchases;
        private System.Windows.Forms.CheckBox chkdiscount_member;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dtpcustomer_since;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown numlistRewards;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
    }
}

