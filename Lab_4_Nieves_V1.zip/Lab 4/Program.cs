﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Xml;


namespace Lab_4
    //Saimer Nieves Scott c# lab 4
{   class ValidationLibrary //begins the validation Library
    {
        //Protects code from including the poop name
        public static bool poop_blocker(string temp)
        {
            //sets bool =  to true and if poop is found changes the value to false
            bool result = false;
            if (temp.Contains("poop"))
            {
                result = true;
            }
            return result;

        
        }
        //Checks to make sure atleast something was left added in
        public static bool IsFilledIn(string temp)
        {
            //sets bool value = to false and if value is greater then 1 it becomes true
            bool result = false;
            if (temp.Length > 0)
            {
                result = true;
            }

            return result;
        }

        //Checks there is a minimum length the same as fill but modified
        public static bool IsFilledmin(string temp, int minlen)
        {
            //Uses the same formula with a minimum however to secure minimum length is secure
            bool result = false;
            if (temp.Length >= minlen)
            {
                result = true;
            }
            return result;
        }

        public static bool IsFilledIn_max(string temp, int max_length)
        {
            //secures user types in maximum length such as for phone numbers and zip codes in the usa
            bool result = false;
            if (temp.Length == max_length)
            {
                result = true;
            }
            return result;
        }

        public static bool Phone_checker(string temp) // A phone checker to secure typed in phone includes dashes seperating its values
        {
            bool blnResult = true;
            //Searches for -
            int Phone_divider = temp.IndexOf("-");
            int Next_Phone_Divider = temp.IndexOf("-", Phone_divider + 1); // searches for values index then adds 1 to it if its less the 2 it remains true 

            //Loks for position of last period
           
             if (Next_Phone_Divider >= 2)
            {
                blnResult = false;
            }
            

            return blnResult;

        }


        public static bool ValidEmail(string temp) // searches for the @ symbol to secure correct email format is typed in
        {
            bool blnResult = true;
            //Searches for @
            int atLocation = temp.IndexOf("@");
            int NextatLocation = temp.IndexOf("@", atLocation + 1);

            //Loks for position of last period
            int periodLocation = temp.LastIndexOf(".");

            if (temp.Length < 8)
            {
                blnResult = false;
            }
            else if (atLocation < 2)
            {
                blnResult = false;
            }
            else if (periodLocation + 2 > (temp.Length))
            {
                blnResult = false;
            }

            return blnResult;
        
        }
    }
    class Program
    {
        //Person structure being created Containing the values of information for a person 
        public class Person // changed from structure to class so it changed to public while categories changed to private
        {
            private string first_name;
            private string middle_name;
            private string last_name;
            private string street_1;
            private string street_2;
            private string city;
            private string state;
            private string zip_code;
            private string phone_number;
            private string email_address;

            //end of categories




            public string First_name 
            {
                get
                {
                    return first_name ;

                }
                set
                {
                    if (ValidationLibrary.poop_blocker(value) == true) //included library poop blocker to block the word poop
                    {
                        first_name = "Your name contains the word poop"; // addvises the user why its data was not inputed
                    }

                    else if (ValidationLibrary.IsFilledIn(value) == true)
                    {
                        first_name = value;
                    }
                    else
                    {
                        first_name = "Invalid first name"; // advises the user its date was not valid if left blank
                    }
                }

            }

            public string Middle_name
            {
                get
                {
                    return middle_name;

                }
                set
                {   if (value == "")
                    {
                        middle_name = "NO Middle Name";
                    }

                    else 
                    {
                        middle_name = value;
                    }
                }

            }

            public string Last_name
            {
                get
                {
                    return last_name;

                }
                set
                {
                    if (ValidationLibrary.IsFilledIn(value) == true)
                    {
                        last_name = value;
                    }

                    else {
                        last_name = "Invalid Must be filled in";
                    }

                }

            }

            public string Street_1
            {
                get
                {
                    return street_1;

                }
                set
                {
                    if (ValidationLibrary.IsFilledIn(value) == true)
                    {
                        street_1 = value;
                    }

                    else
                    {
                        street_1 = "Invalid Must be filled in";
                    }


                }

            }

            public string Street_2
            {
                get
                {
                    return street_2;

                }
                set
                {
                    if (value == "")
                    {
                        street_2 = "NO Street 2 Address";
                    }

                    else
                    {
                        street_2 = value;
                    }

                }

            }

            public string City
            {
                get
                {
                    return city;

                }
                set
                {
                    if (ValidationLibrary.IsFilledIn(value) == true)
                    {
                        city = value;
                    }

                    else
                    {
                        city = "Invalid Must be filled in";
                    }


                }

            }

            public string State
            {
                get
                {
                    return state;

                }
                set
                {
                    if (ValidationLibrary.IsFilledIn_max(value, 2) ==  true)
                    {
                        state = value;
                    }

                    else
                    {
                        state = "INVALID STATE FORMAT ONLY INITALS no Spaces( EXAMPLE = New York = NY)";
                    }

                }

            }

            public string Zip_code
            {
                get
                {
                    return zip_code;

                }
                set

                {
                    if (ValidationLibrary.IsFilledIn_max(value, 5) == true)
                    {
                        zip_code = value;
                    }
                    else
                    {
                        zip_code = "INVALID ZIP CODE IN USA EVERY ZIP CODE IS 5 NUMBERS (EXAMPLE = 02861)";
                    }
                }

            }

            public string Phone_number
            {
                get
                {
                    return phone_number;

                }
                set
                {

                    if (ValidationLibrary.Phone_checker(value)==false)
                    {
                        phone_number = value;
                    }

                    else
                    {
                        phone_number = "(INVALID PHONE NUMBER FORMAT) make sure to include dashes and area code EX 401-777-7777";
                    }



                }

            }

            public string Email_address
            {
                get
                {
                    return email_address;

                }
                set
                {
                    if (ValidationLibrary.ValidEmail(value))
                    {

                        email_address = value;
                    }
                    else
                    {
                        email_address = " INVALID FORMAT (EX:  GeorgerLucas@gmail.com)";
                    }
                }

            }
        }


        static void Main(string[] args)
        {

            
    

            bool blnResult = false;

            Person temp = new Person();

            Console.Write("Name:   ");
            temp.First_name = Console.ReadLine();

            Console.Write("middle name:   ");
            temp.Middle_name = Console.ReadLine();

            Console.Write("Last name:   ");
            temp.Last_name = Console.ReadLine();

            Console.Write("street 1:   ");
            temp.Street_1 = Console.ReadLine();

            Console.Write("street 2:   ");
            temp.Street_2 = Console.ReadLine();

            Console.Write("city:   ");
            temp.City = Console.ReadLine();
            //validaition.ismaxmamount(value,1)==true

            Console.Write("state:   ");
            temp.State = (Console.ReadLine());

            while (temp.State.Length != 2)
            {

                

                    Console.Write("\n Sorry your state name format was invalid..please ONLY STATE THE INITIALS no spaces(Example: New York = NY)");
                    Console.Write("\nstate:   ");
                    temp.State = (Console.ReadLine());
                


            }
            Console.Write("ZIP code:   ");
            temp.Zip_code = Console.ReadLine();




            Console.Write("phone number:   ");
            temp.Phone_number = Console.ReadLine();


            //validaition.isminumumamount(value,1)==true


            //if (validationLibrary.isvalidEmail(value))
            Console.Write("email address:   ");
            temp.Email_address = Console.ReadLine();



            //Output
            Console.WriteLine("\n\n\n\n");
            Console.WriteLine("This is the information recoded from your answers:\n");
            Console.WriteLine($"First Name :  {temp.First_name}");
            Console.WriteLine($"Middle Name : {temp.Middle_name}");
            Console.WriteLine($"Last Name: {temp.Last_name}");
            Console.WriteLine($"Street 1: {temp.Street_1}");
            Console.WriteLine($"Street 2: {temp.Street_2}");
            Console.WriteLine($"City: {temp.City}");
            Console.WriteLine($"Zip Code: {temp.Zip_code}");
            Console.WriteLine($"State: {temp.State}");
            Console.WriteLine($"Phone number:  {temp.Phone_number}");
            Console.WriteLine($"Email:  {temp.Email_address}");



            Console.ReadLine();

        }
    }
}
