﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_2
{
    class Program
    {
        static void Main(string[] args)

        {
            /*Variables*/
            string strStop,
                strLetterGrade;
            string attack = "y";

            int NumOfStudents = 0;

            double  dblIndvAverage = 0, dblGrade_1List_Average = 0,
                dblGrade_2List_Average = 0, dblGrade_3List_Average = 0, dblGrade_4List_Average = 0, dblGrade_5List_Average = 0;
               

            List<string> FirstName = new List<String>();
            List<string> LastName = new List<String>();

            List<double> dblGrade_1List = new List<double>(),
                        dblGrade_2List = new List<double>(),
                        dblGrade_3List = new List<double>(),
                        dblGrade_4List = new List<double>(),
                        dblGrade_5List = new List<double>(),
                        dblIndvAverage_list = new List<double>(),
                        dblTotal_Average = new List<double>();

            Console.WriteLine("WelCome to Our Class Grading System ! C#\n\n");

            //METHODS-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            //Method to return Something
            static double Grades_Average(double dblGrade_1, double dblGrade_2, double dblGrade_3, double dblGrade_4, double dblGrade_5)
            {

                double dblTotal_IndvGrades = dblGrade_1 + dblGrade_2 + dblGrade_3 + dblGrade_4 + dblGrade_5;

                double dblIndvAverage = dblTotal_IndvGrades / 5;

                return dblIndvAverage;

            }




            //Method to repeat while loop
            static string again_function()

            {
                Console.Write("Would you like to enter another student: ");
                string again = Console.ReadLine();

                return again;

            }





            //method to Calcualte the averages of each list added to it
            static double List_Averages(double NumOfStudents, List<double> list_name)
            {

                double dbllistanswer = list_name.Sum(x => Convert.ToDouble(x)) / NumOfStudents;

                return dbllistanswer;

            }



            //Method with conditional statement to include lettergrade conversion
            static void letter_grade_Conversion(double dblIndvAverage, string strLetterGrade)
            {


                if (dblIndvAverage >= 90)
                {
                    strLetterGrade = "A";
                    Console.WriteLine("\n\n\n\tStudent Average: " + strLetterGrade);

                }

                else if (dblIndvAverage >= 80)
                {
                    strLetterGrade = "B";
                    Console.WriteLine("\n\n\n\tStudent Average: " + strLetterGrade);
                }

                else if (dblIndvAverage >= 70)
                {
                    strLetterGrade = "C";
                    Console.WriteLine("\n\n\n\tStudent Average: " + strLetterGrade);
                }

                else if (dblIndvAverage >= 60)
                {
                    strLetterGrade = "D";
                    Console.WriteLine("\n\n\n\tStudent Average: " + strLetterGrade);
                }

                else
                {
                    strLetterGrade = "F";
                    Console.WriteLine("\n\n\n\tStudent Average: " + strLetterGrade);
                }

                Console.WriteLine("---------------------------------------------------------------------------------------------------");

            }



            //Method for inpputing information to the program
            static void input_section(List<string> FirstName, List<string> LastName, List<double> dblGrade_1List, List<double> dblGrade_2List, List<double> dblGrade_3List, List<double> dblGrade_4List, List<double> dblGrade_5List, List<double> dblIndvAverage_list)
            {
                Console.WriteLine("---------------------------------------------------------------------------------------------------");

                Console.Write("\t\nFirst Name:  ");
                //First Name:    
                FirstName.Add(Console.ReadLine());
                

                Console.Write("\t\nLast Name:  ");
                LastName.Add(Console.ReadLine());
                




                Console.WriteLine("\n");


                //Grades Section

                //Grade1
                Console.Write("\t\nEnter Lab Grade 1: ");
                double dblGrade_1 = Convert.ToDouble(Console.ReadLine());
                dblGrade_1List.Add(dblGrade_1);
                

                //Grade2
                Console.Write("\t\nEnter Lab Grade 2: ");
                double dblGrade_2 = Convert.ToDouble(Console.ReadLine());
                dblGrade_2List.Add(dblGrade_2);


                //Grade3
                Console.Write("\t\nEnter Lab Grade 3: ");
                double dblGrade_3 = Convert.ToDouble(Console.ReadLine());
                dblGrade_3List.Add(dblGrade_3);

                //Grade4
                Console.Write("\t\nEnter Lab Grade 4: ");
                double dblGrade_4 = Convert.ToDouble(Console.ReadLine());
                dblGrade_4List.Add(dblGrade_4);


                //Grade5
                Console.Write("\t\nEnter Lab Grade 5: ");
                double dblGrade_5 = Convert.ToDouble(Console.ReadLine());
                dblGrade_5List.Add(dblGrade_5);


                //FUnction to Find the average of Grades 

                double dblStudent_Avg = Grades_Average(dblGrade_1, dblGrade_2, dblGrade_3, dblGrade_4, dblGrade_5); // FUNCTIONNNN
                dblIndvAverage_list.Add(dblStudent_Avg);
                Console.WriteLine("\n\n\n");
            }

            static void Class_Results(double dblGrade_1List_Average, double dblGrade_2List_Average, double dblGrade_3List_Average, double dblGrade_4List_Average, double dblGrade_5List_Average, double NumOfStudents)

            {
                Console.WriteLine(" Class Average: " + "Lab 1: " + dblGrade_1List_Average + "\t\t " + "Lab 2: " + dblGrade_2List_Average + "\t\t " + "Lab 3: " + dblGrade_3List_Average + "\t\t " + "Lab 4: " + dblGrade_4List_Average + "\t " + "Lab 5: " + dblGrade_5List_Average);

                Console.Write("Total Number of Students: " + NumOfStudents);


            }







            //END OF METHODS---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------




            //PROGRAM BEGINS NOW-----------------------------------------------------------






            //Hey Scott I had a while loop begin here but it broke the code and I had a boolean as a condition to begin it 
            //What can I do?
            while (attack == "y")

            {
                //Input information method
                input_section(FirstName, LastName, dblGrade_1List, dblGrade_2List, dblGrade_3List, dblGrade_4List, dblGrade_5List, dblIndvAverage_list);

                NumOfStudents++;

                //Method to ask for information again
                attack = again_function(); //FUNCTION 

            }




            
            dblGrade_1List_Average = List_Averages(NumOfStudents, dblGrade_1List);
            dblGrade_2List_Average = List_Averages(NumOfStudents, dblGrade_2List);
            dblGrade_3List_Average = List_Averages(NumOfStudents, dblGrade_3List);
            dblGrade_4List_Average = List_Averages(NumOfStudents, dblGrade_4List);
            dblGrade_5List_Average = List_Averages(NumOfStudents, dblGrade_5List);


            for (int cntr = 0; cntr < NumOfStudents; cntr++)
            {
             
                //Output a line of a student's info
                Console.WriteLine(FirstName[cntr] + " " + LastName[cntr] + "\t\t");
                Console.WriteLine("Grades : " + "Lab 1) " + dblGrade_1List[cntr] + "\t\t " + "Lab 2) " + dblGrade_2List[cntr] + "\t\t " + "Lab 3) " + dblGrade_3List[cntr] + "\t\t " + "Lab 4) " + dblGrade_4List[cntr] + "\t\t " + "Lab 5) " + dblGrade_5List[cntr]);

                Console.WriteLine("Average:  " + dblIndvAverage_list[cntr]);
                strLetterGrade = "";
                dblIndvAverage = dblIndvAverage_list[cntr];
                letter_grade_Conversion(dblIndvAverage, strLetterGrade);

            }

            Class_Results(dblGrade_1List_Average, dblGrade_2List_Average, dblGrade_3List_Average, dblGrade_4List_Average, dblGrade_5List_Average, NumOfStudents);

            /*GoodBYE*/
            Console.WriteLine("\n\n Thank you for using the program  ");
            strStop = Console.ReadLine();





        }
    }
}
