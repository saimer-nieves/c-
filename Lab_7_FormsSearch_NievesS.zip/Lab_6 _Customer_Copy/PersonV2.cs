﻿using Lab_5_Midterm;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using Lab_4;
using System.Data;
using System.Data.SqlClient;//SQL client allows to interact with the sql server more effienctly //oled universal data base server so it may not be using the most effeienct 
using System.Security.Principal;
using System.Dynamic;
using System.Security.Cryptography.X509Certificates;

namespace Lab_6
{
    class PersonV2 : Person
    {
        private string cell_phone;
        private string instagramURL;


        public string Cell_phone
        {
            get
            {
                return cell_phone;
            }

            set
            {
                //if validation library determined it was good set valeu
                if (ValidationLibrary.Phone_checker(value) == false)
                {
                    cell_phone = value;
                }
                else
                {
                    Feedback += "\nINVALID: Error: Cell Phone Number REQUIRED- make sure to include dashes and area code EX 401-777-7777";
                }
            }
        }

        public string InstagramURL
        {
            get
            {
                return instagramURL;
            }

            set
            {


                //if validation library determined it was good set valeu


                if (ValidationLibrary.InstagramURL_valid(value) == false)
                {
                    instagramURL = value;
                }
                else
                {

                    Feedback += "\nINVALID: Error: Instagram URL REQUIRED- make sure to include (Instagram.com/) infront of URL EX: Instagram.com/accountname";
                }


            }
        }

        public string AddARecord()
        {
            //Init string var
            string strResult = "";

            //Make a connection object
            SqlConnection Conn = new SqlConnection();

            //Initialize it's properties
            Conn.ConnectionString = @"Server=sql.neit.edu,4500;Database=SE245_SNieves;User Id=SE245_SNieves;Password=008008712;";     //Set the Who/What/Where of DB


            //*******************************************************************************************************
            // NEW
            //*******************************************************************************************************
            string strSQL = "INSERT INTO [SE245_SNieves].[dbo].[PersonV2_Table] (First_name, Middle_name, Last_name, Street_1, Street_2, City, State, Zip_code,Phone_number,Cell_phone, Email_address, InstagramURL) VALUES (@First_name, @Middle_name, @Last_name, @Street_1, @Street_2, @City, @State, @Zip_code,@Phone_number,@Cell_phone, @Email_address, @InstagramURL)";
            // Bark out our command
            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;  //Commander knows what to say
            comm.Connection = Conn;     //Where's the phone?  Here it is

            //Fill in the paramters (Has to be created in same sequence as they are used in SQL Statement)
            comm.Parameters.AddWithValue("@First_name", First_name);
            comm.Parameters.AddWithValue("@Middle_name", Middle_name); 
            comm.Parameters.AddWithValue("@Last_name", Last_name);
            comm.Parameters.AddWithValue("@Street_1", Street_1);
            comm.Parameters.AddWithValue("@Street_2", Street_2);//PROBLEM ""
            comm.Parameters.AddWithValue("@City", City);
            comm.Parameters.AddWithValue("@State", State);
            comm.Parameters.AddWithValue("@Zip_code", Zip_code);
            comm.Parameters.AddWithValue("@Phone_number", Phone_number);
            comm.Parameters.AddWithValue("@Cell_phone", Cell_phone);
            comm.Parameters.AddWithValue("@Email_address", Email_address);
            comm.Parameters.AddWithValue("@InstagramURL", InstagramURL);



            //==============================barkng orders////////////////////////////////





            //attempt to connect to the server
            try
            {
                Conn.Open();                                        //Open connection to DB - Think of dialing a friend on phone
                int intRecs = comm.ExecuteNonQuery();
                strResult = $"SUCCESS: Inserted {intRecs} records.";       //Report that we made the connection and added a record
                Conn.Close();                                       //Hanging up after phone call
            }
            catch (Exception err)                                   //If we got here, there was a problem connecting to DB
            {
                strResult = "ERROR: " + err.Message;                //Set feedback to state there was an error & error info
            }
            finally
            {

            }



            //Return resulting feedback string
            return strResult;
        }

        public DataSet search_in_PersonV2(string strFirst_nameValue, string strLast_nameValue)
        {
            DataSet data_list = new DataSet();  // create a box for it to hold more mugs or more datasets within it
            SqlCommand order_in_Sql = new SqlCommand(); // is ordering and requesting and organzing things from our sql table

            string strSQL_Properties = "SELECT First_name, Middle_name, Last_name , Street_1, Street_2 , City, State, Zip_code, Phone_number, Cell_phone, Email_address, InstagramURL, User_ID FROM PersonV2_Table WHERE 0=0"; //selects properties from table where 0=0

            if (strFirst_nameValue.Length > 0) // when information is in text box
            {
                strSQL_Properties += " AND First_name LIKE @First_name"; // look for anuthing in the first names that contain it
                order_in_Sql.Parameters.AddWithValue("@First_name", "%" + strFirst_nameValue + "%"); // i dont care what it begisn or ends with as long is variable is within it
            }
            if (strLast_nameValue.Length > 0) // when information is added
            {
                strSQL_Properties += " AND Last_name LIKE @Last_name";//adds search property for sql commander
                order_in_Sql.Parameters.AddWithValue("@Last_name", "%" + strLast_nameValue + "%");// look for anuthing in the first names that contain it
            }

            //connection to the sql server
            SqlConnection connect = new SqlConnection();

            string strConnection_value = @Access_Database();
            connect.ConnectionString = strConnection_value; // connectts the SQL connection to Access string

            order_in_Sql.Connection = connect; // gives the connection to the orders to be fulfilled
            order_in_Sql.CommandText = strSQL_Properties; //Gives the orders of SQL the properties to use when reuqesting infor

            SqlDataAdapter Data_Display_Adapter = new SqlDataAdapter();//Obtains infomration and adjusts it into our view
            Data_Display_Adapter.SelectCommand = order_in_Sql;//translate information into dataset for easy viewing



            //Obtain Data
            connect.Open(); // opens the connection
            Data_Display_Adapter.Fill(data_list, "Personv2_Temp"); //fill the list with information translated from the adpater and called it personv2
            connect.Close();


            return data_list;







        }

        //program to read information from table
        public SqlDataReader Find_person(int intUser_ID)
        {
            //Database tools to connect 
            SqlConnection connect = new SqlConnection();
            //Database Commander of orders
            SqlCommand order_Sql = new SqlCommand();
        
            //connect to string
            string strConnection_value = @Access_Database(); // connecting to the string of the database
        
            //Sql command to pull information from one coulumn
            string sqlString = "SELECT * FROM PersonV2_Table WHERE User_ID = @User_ID";
        
            //try to make sql connection with this string
            connect.ConnectionString = strConnection_value;
        
            //Giving the command objects the info it needs to execute
        
            order_Sql.Connection = connect; //connect orderts to sql connection
            order_Sql.CommandText = sqlString;//give it the orders to request information
            order_Sql.Parameters.AddWithValue("@User_ID", intUser_ID); //bring that value onto this variable
        
            //Open the gates and go in and bark orders
            connect.Open();
        
            //return some information feedback if executed properly
            return order_Sql.ExecuteReader(); // retrurns the information associated with the call
        
        }

        private string Access_Database()
        {
            return "Server=sql.neit.edu,4500;Database=SE245_SNieves;User Id=SE245_SNieves;Password=008008712;";
        }

        public PersonV2()                               
        {                                              
         cell_phone = "";                             
         instagramURL = "Instagram.com/";                
        }                                                 
    }                                                     
                                                         






    
}
