﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lab_5_Midterm;

namespace Lab_6
{
    public partial class Search : Form
    {
        public Search()
        {
            InitializeComponent();
        
        
        }

        

        private void btnSearch_Click(object sender, EventArgs e)
        {
            PersonV2 temp = new PersonV2(); // gets data and collects it into a new mug
            DataSet data_list = temp.search_in_PersonV2(txtfname_search.Text, txtlname_search.Text); //searching in person v2 based on how we configured it //returns list with configured data

            //display data
            dgvResults.DataSource = data_list; // give datagrid the dataset
            dgvResults.DataMember = data_list.Tables["Personv2_Temp"].ToString(); //gets the mug in the box of mugs and conversts to string
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }
        //sender uses object property type, when click on a cell  sender is a copy of the datagrid and e is the information about the event occur
        private void dgvResults_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            string strPerson_select = dgvResults.Rows[e.RowIndex].Cells[12].Value.ToString(); //gathers info from the row clicked
            string strPerson_fnameview = dgvResults.Rows[e.RowIndex].Cells[0].Value.ToString();
            string strPerson_lnameview = dgvResults.Rows[e.RowIndex].Cells[2].Value.ToString();

            // Display data in Pop-up
            MessageBox.Show("Person ID: #" + strPerson_select + "\n\nUser: " + strPerson_fnameview +"\n          "+ strPerson_lnameview);

            //Convert the string over to an integer
            int intUser_ID = Convert.ToInt32(strPerson_select);

            //Create the editor form, passing it one EBook's ID and show it
            //NOTE THAT THE ID BEING PASSED WILL CALL THE OVERLOADED VERSION
            //OF THE CONSTRUCTOR...TELL IT, IN ESSENCE THAT WE ARE PULLING UP
            // RATHER THAN ADDING DATA 
             Form1 Editor = new Form1(intUser_ID);
             Editor.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }
    }
}
