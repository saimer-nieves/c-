﻿using Lab_5_Midterm;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_6
{
    public partial class Controlpanel : Form
    {
        public Controlpanel()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Form1 temp = new Form1();
            temp.ShowDialog();   // doesnt let you jump back and forth
                                //shows lets you go back and forth between each form

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            Search temp = new Search();
            temp.Show();
        }
    }
}
